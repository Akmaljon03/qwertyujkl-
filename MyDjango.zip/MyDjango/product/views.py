from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import render
from .models import Product
from django.contrib.auth.forms import UserCreationForm

def index (request):
    return  HttpResponse("Hello World!")

def user_register(request):
    form=UserCreationForm()
    if request.method == 'POST':
        form=UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
    context ={
        'form':form,
        'title':'Register'}

    return render(request,'register.html', context)